package m08_FINAL;

public class StudentA {	
	public double fallQuarter = 0;
	public double springQuarter = 0;	
	public double winterQuarter = 0;
	public double summerQuarter = 0;
	
	// should equal to 0
}
