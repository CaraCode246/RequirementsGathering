package m08_FINAL;

public class Student {
    public Student(double fallQuarter, double springQuarter, double winterQuarter, double summerQuarter) {

        Math math = new Math(0,0,0,0);
        double total = math.getTotalCredits();
        
        System.out.println(total);
        if(total<=0) {
			System.out.println("you are a new student, welcome");
		}else if(total<=10 && total<=84) {
			System.out.println("you are a continuing student");
		}else if( total>=85 && total<=299) {
			System.out.println("Warning fill out a extension form");
		}
		else {
			System.out.println("you have too many credits for financial aid!");
		}

    }

}
