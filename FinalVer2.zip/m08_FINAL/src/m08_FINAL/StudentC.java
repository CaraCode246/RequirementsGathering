package m08_FINAL;

public class StudentC {
	public double fallQuarter = 24;
	public double springQuarter = 20;
	public double winterQuarter = 20;
	public double summerQuarter = 25;

	//should equal to 89
}