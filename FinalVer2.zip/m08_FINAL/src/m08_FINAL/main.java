package m08_FINAL;
import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		
		// add scanner method to add numbers to SudentA, SudentB, SudentC. 
		// after calculating should print amount to screen by using line 15 ,20, and 25.
		Scanner scanner = new Scanner(System.in );
		
		
	SudentA();{
		double course = scanner.nextInt();
		double total= course + Math.totalCredits;
		System.out.println("you have"+ total + "number of course credits");
	}
	SudentB();{
		double course = scanner.nextInt();
		double total= course + Math.totalCredits;
		System.out.println("you have"+ total + "number of course credits");  
	}
	SudentC();{
		double course = scanner.nextInt();
		double total= course + Math.totalCredits;
		System.out.println("you have"+ total + "number of course credits");
		}	
	}
	
	private static void SudentA() {
		Student studentA = new Student(0,0,0,0);
	}

	
	private static void SudentB() {
		Student studentB = new Student(25,25,25,25);
		
	}

	private static void SudentC() {
		Student studentC = new Student(24,20,20,25);
	}
//what the program cannot do
	//add exception NO negate numbers
	//the exceptions have a error and will not run.
	@Override
	Exception a (total == negative number ) {
		System.out.println("invalid number cannot be negative ");
	}
	//add exception where number can't go over 300
	@Override
	Exception b (total >= 300) {
		System.out.println("invalid number this number is to high");
	}
}
