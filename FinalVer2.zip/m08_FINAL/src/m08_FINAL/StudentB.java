package m08_FINAL;

public class StudentB {
	public double fallQuarter = 25;
	public double springQuarter = 25;
	public double winterQuarter = 25;
	public double summerQuarter = 25;
	
	//should equal to 100
}
