package m08_FINAL;

public class Math {
	static double totalCredits; // private = restricted access

	// Add up the total credits for all 4 quarters
	public Math(double fallQuarter, double springQuarter, double winterQuarter, double summerQuarter) 
	{
		totalCredits = Double.sum(Double.sum(fallQuarter, springQuarter),Double.sum(winterQuarter, summerQuarter));
	}
	public Double getTotalCredits() {
		return totalCredits;
	}

}

